package bank;

import java.sql.*;

public class DataSource {

    public static Connection connect() {

        String db_file = "jdbc:sqlite:src/main/resources/bank.db";
        Connection connection = null;
        try{
            connection = DriverManager.getConnection(db_file);
        }catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public static Customer getCustomer(String unsername) {
        Customer customer = null;
        String sql = "select * from Customers where username = ?";
        try(Connection connection = connect(); PreparedStatement statement = connect().prepareStatement(sql)){

            statement.setString(1 , unsername);
            try(ResultSet resultSet = statement.executeQuery()) {
                customer = new Customer(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("username"),
                        resultSet.getString("password"),
                        resultSet.getInt("account_id"));
            }

        }catch (SQLException e){
            e.printStackTrace();
        }
        return customer;
    }

    public static Account getAccount(int account_id) {
        Account account = null;
        String sql = "select * from Accounts where id = ?";
        try(Connection connection = connect(); PreparedStatement statement = connect().prepareStatement(sql)){

            statement.setInt(1 , account_id);
            try(ResultSet resultSet = statement.executeQuery()) {
                account = new Account(
                        resultSet.getInt("id"),
                        resultSet.getString("type"),
                        resultSet.getDouble("balance"));
            }

        }catch (SQLException e){
            e.printStackTrace();
        }
        return account;
    }

    public static void updateAccountBalance(int accountId, double balance) {
        String sql = "update accounts set balance = ? where id = ?";

        try(Connection connection = connect(); PreparedStatement statement = connection.prepareStatement(sql);){

            statement.setDouble(1 , balance);
            statement.setInt(2, accountId);

            statement.executeUpdate();

        }catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
