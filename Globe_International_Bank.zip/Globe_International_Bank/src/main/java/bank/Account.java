package bank;

import bank.exceptions.AmountException;

public class Account {

    private int id;
    private String type;
    private double balance;

    public Account(int id, String type, double balance) {
        setId(id);
        setType(type);
        setBalance(balance);
    }

    public void deposit(double amount) throws AmountException {
        if (amount < 1) {
            throw new AmountException("The minimum deposite is $1.00");
        }else {
            double newBalance = balance + amount;
            setBalance(newBalance);
            DataSource.updateAccountBalance(id, newBalance);
        }
    }

    public void withdraw(double amount){
        if (amount < 0) {
            System.out.println("The withdrawal amount must be greater than $0.00");
        }
        if (amount > getBalance()) {
            System.out.println("You don't have sufficient funds for this withdrawal!");
        }
        else {
            double newBalance = balance - amount;
            setBalance(newBalance);
            DataSource.updateAccountBalance(id, newBalance);
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
