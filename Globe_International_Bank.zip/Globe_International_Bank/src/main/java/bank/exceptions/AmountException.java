package bank.exceptions;

public class AmountException extends Exception{

    public AmountException(String message) {
        super(message);
    }
}
